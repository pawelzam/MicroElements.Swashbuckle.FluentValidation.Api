using FluentValidation;
using FluentValidation.AspNetCore;
using MicroElements.Swashbuckle.FluentValidation.AspNetCore;
using System;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();

builder.Services.AddScoped<IValidator<Address>, AddressValidator>();
builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddFluentValidationClientsideAdapters();
builder.Services.AddValidatorsFromAssemblyContaining<AddressValidator>();
builder.Services.AddSwaggerGen();

builder.Services.AddFluentValidationClientsideAdapters();


builder.Services.AddFluentValidationRulesToSwagger();

var app = builder.Build();
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();


app.MapPost("/address", (Address address) =>
{
    Console.WriteLine(address);
})
.WithOpenApi();

app.Run();


public class AddressValidator : AbstractValidator<Address>
{
    public AddressValidator()
    {
        RuleFor(x => x.StreetName).MinimumLength(2).NotEmpty();
    }
}

public record Address
(
    string StreetName
);

//public class Address
//{
//    public string StreetName { get; set; } = string.Empty;

//    public override string ToString()
//    {
//        return StreetName;
//    }
//};